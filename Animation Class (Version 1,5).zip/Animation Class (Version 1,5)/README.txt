Author: Mayur Singh (IamTeknik)
Version: 1.5
Description: Custom Java swing animation class to move jLabels and jTextFields. More components to be added in future versions.

**Important**
Make sure to use Null Layout for your projects GUI.

To view the API, open the "javadoc" folder and locate the file named "index". This is an HTML file which will open in your browser and you may browse through descriptions on what each parameter requires.
You can ZIP the "javadoc" folder and add it to Eclipse or Netbeans so that it gives information while you use the class. It is more convinient but this is a very easy to use API so it's not needed. Follow the link next to the "Download" button on my website (www.teknikindustries.com) to watch an example on how to use the entire API.

Thank you for downloading :)